<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Registrasi</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<?php
	require('db.php');
    if (isset($_REQUEST['nik'])){
		$nik = stripslashes($_REQUEST['nik']);
        $nik = mysqli_real_escape_string($con,$nik);
        
        $nama = stripslashes($_REQUEST['nama']);
		$nama = mysqli_real_escape_string($con,$nama);
        
        $username = stripslashes($_REQUEST['username']);
        $username = mysqli_real_escape_string($con,$username);
        
        $password = stripslashes($_REQUEST['password']);
        $password = mysqli_real_escape_string($con,$password);
        
     
        $query = "INSERT into `admin` (nik, nama, username, password) VALUES ('$nik', '$nama', '$username', '".md5($password)."')";
        $result = mysqli_query($con,$query);
        if($result){
            echo "<div class='form'><h3>You are registered successfully.</h3><br/>Click here to <a href='login.php'>Login</a></div>";
        }
    }else{
?>
<div class="form">
<h1>Registrasi</h1>
<form name="registration" action="" method="post">
<input type="text" name="nik" maxlength="16" placeholder="Nik" required />
<input type="text" name="nama" placeholder="Nama" required />
<input type="text" name="username" placeholder="Nama Pengguna" required />
<input type="text" name="password" placeholder="Password" required />
<input type="submit" name="submit" value="Register" />
</form>
<br /><br />
</div>
<?php } ?>
</body>
</html>
